# IMusic Android APK build (phone-friendly)

यह पैकेज मूल Google AI Studio React/TypeScript प्रोजेक्ट को Capacitor Android wrapper और GitHub Actions cloud build के लिए तैयार करता है। APK अपने-आप ZIP पर क्लिक करते ही नहीं बनता; GitHub पर एक बार project upload करके workflow चलाना होगा।

## Android मोबाइल से APK बनाना
1. ZIP को Extract करें।
2. GitHub पर नया खाली repository बनाएं: https://github.com/new
3. Extract किए गए project के अंदर की सभी files/folders repository में upload करें (ZIP को nested ZIP की तरह upload न करें)।
4. Repository में Actions tab खोलें। अगर workflow enable करने को कहे तो enable करें।
5. `Build IMusic Android APK` workflow चुनें और `Run workflow` दबाएं।
6. Build पूरा होने पर उसी run के नीचे `IMusic-debug-APK` artifact डाउनलोड करें।
7. Artifact ZIP को फोन में extract करें; `app-debug.apk` install करें। पहली बार Android unknown-app install permission मांगेगा।

## इस build में क्या शामिल है
- मौजूदा React UI और bundled assets APK में पैक होंगे।
- Capacitor Android container बनेगा।
- GitHub Actions Android debug APK compile करेगा।

## ईमानदार फीचर स्थिति / जरूरी सीमाएं
- मौजूदा "Scan" flow Android MediaStore native scan नहीं है; यह browser file picker से चुनी गई फाइलों को जोड़ता है।
- Media3/ExoPlayer foreground service, वास्तविक lock-screen/media notification controls और Android native equalizer अभी इस project में implemented नहीं हैं। Web Audio equalizer browser/WebView के भीतर है।
- Gemini chat अभी `/api/chat` नाम के Express backend को call करती है। Backend को अलग HTTPS server पर deploy करके `src/components/GeminiChatSheet.tsx` में API URL configure करना होगा; Gemini API key APK में रखना सुरक्षित नहीं है। बिना backend के Gemini chat काम नहीं करेगी।
- इसलिए यह ZIP APK build pipeline तैयार करती है, लेकिन ऊपर के native features को पूर्ण रूप से जोड़ने का दावा नहीं करती। इन्हें अलग native Android development और device testing चाहिए।

## Build requirements
GitHub Actions internet-hosted runner पर Node.js, Java और Android SDK install करके APK बनाता है। Local Android Studio/PC की जरूरत नहीं। यह debug APK है, Play Store release-signed APK नहीं।
